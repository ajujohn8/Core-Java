package com.greatlearning.twitterapp.client;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.greatlearning.twitterapp.controller.UserController;
import com.greatlearning.twitterapp.model.Tweet;
import com.greatlearning.twitterapp.model.User;

public class Client {
	private static UserController controller;
	private static Scanner input = new Scanner(System.in);
	private static Scanner input2 = new Scanner(System.in);
	
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("application-context.xml");
		controller = applicationContext.getBean(UserController.class);
		
		
		createUsers();
		postTweets();
		getTweetsByUser();
		follow();
		unfollow();
		updateUser();
		deleteUser();
		deleteTweet();
		//getAllFollowingsByUser();
		//getAllFollowersByUser();
	}
	
	private static void createUsers() {
		List<User> users = new ArrayList<>();
		
		User user1 = new User("ajujohn08", "asafc", "Aju", "Thomas", "aju@gmail.com", 25);
		User user2 = new User("rahulSharma", "ASdxzc", "Rahul", "Sharma", "rahul@gmail.com", 35);
		User user3 = new User("RobinRoy", "adsfc", "Robin", "Roy", "royrobin@gmail.com", 19);
		User user4 = new User("BharatKumar", "2e21sa", "Bharat", "Kumar", "bharat@gmail.com", 28);
		User user5 = new User("Kirank", "sad32d", "Kiran", "k", "kiran2@gmail.com", 24);
		users.add(user1);
		users.add(user2);
		users.add(user3);
		users.add(user4);
		users.add(user5);
		
		for(User user : users) {
			controller.createUser(user);
		}	
	}
	
	private static void postTweets() {
		System.out.println("Post Tweet");
		
		System.out.println("Enter userId");
		Long userId1 = input.nextLong();
		User user1 = controller.find(userId1);
		if(user1 != null) {
			System.out.println("Enter tweet");
			String tweetMessage = input2.nextLine();
			Tweet tweet1 = new Tweet(tweetMessage, user1);
			controller.postTweet(tweet1);
			
		}
		
	}
	
	private static void getTweetsByUser() {
		System.out.println("Display of Tweet");
		
		System.out.println("Enter userId");
		Long userId1 = input.nextLong();
		Set<Tweet> tweetsByUser = new HashSet<>();
		tweetsByUser.addAll(controller.getAllTweets(userId1));
		System.out.println("****** Tweets ******");
		if(tweetsByUser.size() == 0) {
			System.out.println("No tweets found !!!");
		} else {
			for(Tweet tweet : tweetsByUser) {
				System.out.println(tweet);
			}
		}
		
	}
	
	private static void follow() {	
		controller.follow(1L, 4L);
		controller.follow(4L, 5L);
		controller.follow(1L, 3L);
		controller.follow(1L, 2L);
		controller.follow(5L, 3L);
		controller.follow(2L, 3L);
		controller.follow(2L, 1L);

	}
	
	private static void unfollow() {	
		controller.follow(5L, 3L);

	}
	
	private static void updateUser() {
		User updateUser = new User("Kirank", "sad32d", "Kiran", "kumar", "kiran2@gmail.com", 24);
		controller.update(5L, updateUser);
	}
	
	private static void deleteUser() {
		controller.delete(3L);
	}
	
	private static void deleteTweet() {
		controller.deleteTweet(1L, 7L);
	}
	
	private static void getAllFollowingsByUser() {
		System.out.println("Display Following");
		System.out.println("Enter Id");
		Long userId = input.nextLong();
		Set<User> followings = controller.getAllFollowingsByUser(userId);
		if(followings.size() == 0) {
			System.out.println("No followings !!!");
		} else {
			for(User following : followings) {
				System.out.println(following);
			}
		}	
	}
	
	private static void getAllFollowersByUser() {
		System.out.println("Display followers");
		System.out.println("Enter Id");
		Long userId = input.nextLong();
		Set<User> followers = controller.getAllFollowersByUser(userId);
		if(followers.size() == 0) {
			System.out.println("No followers !!!");
		} else {
			for(User follower : followers) {
				System.out.println(follower);
			}
		}
	}
	
}
