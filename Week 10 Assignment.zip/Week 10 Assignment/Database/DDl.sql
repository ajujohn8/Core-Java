create database if not exists twitter_db;

use twitter_db;
show tables;

select * from users;
select * from tweets;

drop database twitter_db;