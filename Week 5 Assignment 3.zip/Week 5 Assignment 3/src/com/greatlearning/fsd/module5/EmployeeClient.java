package com.greatlearning.fsd.module5;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

interface filterCriteria<T>{
	boolean filter(T t);
}



class AgeGt implements Predicate<Employee>{
	private int age;
	public AgeGt(int age) {
		this.age = age;
	}

	public boolean test(Employee e) {
		return e.getAge() > this.age;
	}
	
}

class SalaryGt implements Predicate<Employee>{
	private double salary;
	public SalaryGt(double acceptNumber) {
		this.salary = acceptNumber;
	}

	public boolean test(Employee e) {
		return e.getSalary() > this.salary;
	}
	
}

class DepEqHR implements Predicate<Employee>{
	
	private String department;
	public DepEqHR(String department) {
		this.department = department;
	}

	public boolean test(Employee e) {
		return e.getDepartment().equalsIgnoreCase(this.department);
	}
	
}

public class EmployeeClient {

	/* e. Write a Client class with main method and create 10 instances of employees with different values.
   f. Inside the Client class, write a filterEmployee method, which takes a Predicate as argument and returns the filtered employees 

       private static List<Employee> filterEmployees(Predicate<Employee> predicate ){
           //TODO
       }
   g. Inside the main method,use Scanner class to accept inputs for the below use cases and call the filterEmployee with the below lambda expressions 
       option 1 for (i) usecase to accept a number
       i. Filter the employees having age less than the given input value.
       option 2 for (ii) usecase to accept a number
       ii. Filter all the employees having age more than given input value. 
       option 3 for (iii) usecase to accept a number and string(department)
       iii. Filter all the employees having salary more than the given value and belong to the given department.
       option 4 for (iv) usecase to accept a number and string(department)
       iv. Print the name of the employees whose salary is greater than the input value and belong to the given department.(Use streams API's filter and map for mapping the name from employee) 
*/
	
	public static void main(String[] args) {
		
		List<Employee> employeeList = populateData();
		System.out.println("1. Filter the employees having age less than the given input value.");
		System.out.println("2. Filter all the employees having age more than given input value.");
		System.out.println("3. Filter all the employees having salary more than the given value and belong to the given department.");
		System.out.println("4. Print the name of the employees whose salary is greater than the input value and belong to the given department.(Use streams API's filter and map for mapping the name from employee)");
		System.out.println("\n Please enter any number b/w 1 to 4");

		Scanner sc = new Scanner(System.in);
		int ageCheck;
		String department;
		double salary;
		int option = sc.nextInt();
		List<Employee> filterEmployees = null;
		
		switch (option) {
		case 1:
			System.out.print("Enter age: ");
			ageCheck = sc.nextInt();
			Predicate<Employee> ageLessThan = new AgeGt(ageCheck).negate();
			filterEmployees =  filterEmployees(employeeList,ageLessThan);
			filterEmployees
			.stream()
			.forEach((employee) ->System.out.println(employee));
			break;
		case 2:
			System.out.print("Enter age: ");
			ageCheck = sc.nextInt();
			Predicate<Employee> ageGreaterThan = new AgeGt(ageCheck);
			filterEmployees =  filterEmployees(employeeList,ageGreaterThan);
			filterEmployees
			.stream()
			.forEach((employee) ->System.out.println(employee));
			break;
		case 3:
			System.out.print("Enter department: ");
			department = sc.next();
			System.out.print("Enter salary: ");
			salary = sc.nextDouble();
			Predicate<Employee> salaryGreaterThan = new SalaryGt(salary).and(new DepEqHR(department));
			filterEmployees =  filterEmployees(employeeList,salaryGreaterThan);
			filterEmployees
			.stream()
			.forEach((employee) ->System.out.println(employee));
			break;

		case 4:
			System.out.print("Enter department: ");
			department = sc.next();
			System.out.print("Enter salary: ");
			salary = sc.nextDouble();
			Predicate<Employee> salaryGreater= new SalaryGt(salary).and(new DepEqHR(department));
			filterEmployees =  filterEmployees(employeeList,salaryGreater);
			filterEmployees
			.stream()
			.map(emp-> emp.getName())
			.forEach((emp) -> System.out.println("Name : "+emp));	
			break;

			
		default:
			System.out.println("Wrong Input");
			break;
		}
		
		sc.close();
		
	}
	
	private static List<Employee> filterEmployees(List<Employee> employeeList, Predicate<Employee> predicate){
		
		List<Employee> filterEmployee = new ArrayList<Employee>();
		Iterator<Employee> it = employeeList.iterator();
		while (it.hasNext()) {
			Employee currentEmployee = it.next();
			if(predicate.test(currentEmployee)) {
				filterEmployee.add(currentEmployee);
			}
			
		}
		return filterEmployee;
	}
	

	
	private static List<Employee> populateData(){
		List<Employee> list = new ArrayList<Employee>();
		list.add(new Employee(1, "Sam", 23, "HR", 20000));
		list.add(new Employee(2, "Ram", 22, "FINANCE", 32000));
		list.add(new Employee(3, "Vijay", 26, "MARKETING", 17000));
		list.add(new Employee(4, "Mohan", 23, "SALES", 32000));
		list.add(new Employee(5, "Tom", 33, "FINANCE", 45000));
		list.add(new Employee(6, "Vignesh", 26, "MARKETING",21000));
		list.add(new Employee(7, "Abhilash", 44, "SALES", 48000));
		list.add(new Employee(8, "Sid", 23, "HR", 23000));
		list.add(new Employee(9, "Anmol", 28, "MARKETING", 27000));
		list.add(new Employee(10, "Anil", 22, "FINANCE", 18000));
		return list;

		
	}
}



