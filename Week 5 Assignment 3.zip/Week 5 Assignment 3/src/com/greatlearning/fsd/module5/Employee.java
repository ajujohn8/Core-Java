package com.greatlearning.fsd.module5;

import java.util.Comparator;

public class Employee implements Comparator<Employee> {
	/* a. Write a Employee class with id (int), name (String), age (int), department(HR,FINANCE, MARKETING,SALES) and salary(double)
   b. Create a public constructor accepting id,name, age and salary .
   c. Create an overloaded constructor accepting id, name, age, salary and department.
   d. Override the equals, toString, hashCode and implement Comparable interface */
	
	private int id;
	private String name;
	private int age;
	private String department;
	private double salary;
	
	public Employee(int id, String name, int age, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.salary = salary;
	}

	public Employee(int id, String name, int age, String department, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.department = department;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + age;
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (age != other.age)
			return false;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "\n" + "id=" + this.id + ", name=" + this.name + ", age=" + this.age 
				+ ", department=" + this.department + ", salary=" + this.salary ;
	}

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	}
	
	
	
	
	


