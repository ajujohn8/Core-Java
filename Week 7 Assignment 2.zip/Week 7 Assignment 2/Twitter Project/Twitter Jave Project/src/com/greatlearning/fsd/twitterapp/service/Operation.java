package com.greatlearning.fsd.twitterapp.service;

public enum Operation {
	INSERT, QUERY, UPDATE, DELETE
}
