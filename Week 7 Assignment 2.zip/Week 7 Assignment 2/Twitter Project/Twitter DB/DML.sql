use twitter_db;
show tables;

insert into user (user_handle, password, first_name, last_name, email_address, profile_pic, cover_pic, created_date)
    values ('ajujohn08', 'afsafq', 'Aju', 'Thomas', 'aju@gmail.com', 'Picture', 'Picture ', '2019-08-04'),
    ('ram21', '2141214r', 'Ram', 'Das', 'ram@gmail.com', 'Picture', 'Picture', '2019-08-04'),
	('sam232', 'sd124', 'Sam', 'Thomas', 'sam@gmail.com', 'Picture', 'Picture', '2019-08-04'),
    ('Amoolya55', 'assf214', 'Amoolya', 'Jayaram', 'amoolya@gmail.com', 'Picture ', 'Picture', '2019-08-04'),
    ('Rani12e', 'sdgs324', 'Rani', 'Kumari', 'rani@gmail.com', 'Picture', 'Picture ', '2019-08-04');
        
insert into follower_following (follower_id, following_id)
	values (1, 2),
    (1, 3),
	(1, 4),
	(1, 5),
	(2, 3),
	(2, 4),
	(2, 5),
	(3, 4),
	(3, 5),
	(4, 2),
	(4, 3),
	(5, 3),
	(5, 4);
        
insert into tweet (user_id, tweet_message, created_date, likes)
	values(1, 'Opposition delegation led by Rahul Gandhi boards flight to Srinagar', '2019-08-04', 5),
    (3, 'Chandrayaan 2 enters moon orbit', '2019-08-04', 20),
    (3, 'Neymar expecting to join new club', '2019-08-04', 1),
    (5, 'Happy working!!!', '2019-08-04', 100),
    (4, 'Happy Birthday', '2019-08-04', 2),
    (2, 'Work Hard', '2019-08-04', 410);
  
    
insert into comment (tweet_id, user_id, text, created_date)
	values(2, 1, 'Nice', '2019-08-04'),
    (4, 1, 'Good luck ', '2019-08-02'),
    (5, 1, 'Best of luck', '2019-08-04'),
    (6, 3, 'good', '2019-08-04'),
    (8, 5, 'Nice', '2019-08-04');
    
select * from user;
select * from follower_following;
select * from tweet;
select * from comment;