package com.greatlearning.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ListUsersServlet extends HttpServlet {
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {		 	 
		List<User> user = UsersUtil.getUsersFromDB();
		req.setAttribute("userList", user);
		RequestDispatcher reqDisp = req.getRequestDispatcher("/JSP/displayUsers.jsp");
		reqDisp.forward(req, res);
	}
}
