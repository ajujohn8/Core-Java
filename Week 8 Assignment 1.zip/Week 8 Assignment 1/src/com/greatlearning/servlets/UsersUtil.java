package com.greatlearning.servlets;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class UsersUtil {
	
	static List<User> getUsersFromDB() {
		List<User> users = new ArrayList<>();
		Connection connection = null;
		Optional<Connection> optionalConnection = JDBCUtil.getConnection();
		if (optionalConnection.isPresent()) {
			try {
				connection = optionalConnection.get();
				users.addAll(fetchUsers(connection));	
			} finally {
				if(connection != null) {
					try {
						connection.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}

		return users;
	}
	private static List<User> fetchUsers(Connection connection) {
		List<User> users = new ArrayList<>();
		try (Statement statement = connection.createStatement()) {
			String query = "Select * from user";
			ResultSet resultSet = statement.executeQuery(query);
			while (res.next()) {
				int id = res.getInt(1);
				String name = res.getString(2);
				int age = res.getInt(3);
				String location = res.getString(4);
				User user = new User(id, name, age, location);
				users.add(user);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		return users;
	}
}
