insert into user (name, age, location)
	values ('Aju', 24, 'Kerala'),
	('Sam', 40, 'Mumbai'),
    ('Ram', 15, 'Delhi'),
    ('Ramesh', 64, 'Ranchi');
    
