create database if not exists user_db;

use user_db;

create table if not exists user (
	id int unsigned primary key auto_increment,
    name varchar(50),
    age int unsigned,
    location varchar(50)
    );
    
drop table user;
drop database user_db;