package com.greatlearning.readwriteloop;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WriteFile {
	private static final String FILE_PATH = "E:\\Week 6 Assignment 3\\src\\com\\greatlearning\\readwriteloop\\numberdata.txt";
	
	public static void main(String[] args) {	
		File file = new File(FILE_PATH);
		try (FileWriter writer = new FileWriter(file,true)) {
			int number = 1;
			while(number <= 100) {
				writer.write(number + " ");
				number++;
			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
}
