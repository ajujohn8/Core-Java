package com.greatlearning.model;

import java.util.concurrent.BlockingQueue;

public class Distributor implements Runnable {
	

	private final BlockingQueue<Integer> inventory;
	private static int counter = 0;
	private final int maxsize;


	public Distributor(BlockingQueue<Integer> inventory, int size) {
		this.inventory = inventory;
		this.maxsize = size;
	}

	@Override
	public void run() {
		while (true) {
			updateInventory(++counter);
		}
	}

	private void updateInventory(int counter)  {
		synchronized (inventory) {
			if (this.inventory.size() == maxsize) {
					try {
						inventory.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
			} 
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			this.inventory.add(counter);
			System.out.println("Distributer is adding "+ counter);
			
			inventory.notifyAll();
		}
	}

	
}
	
	








