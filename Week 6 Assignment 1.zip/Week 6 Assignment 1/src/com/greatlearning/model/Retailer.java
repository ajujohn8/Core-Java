package com.greatlearning.model;

import java.util.concurrent.BlockingQueue;


public class Retailer implements Runnable {

	
	private static int counter = 0;

	private final BlockingQueue<Integer> inventory;


	public Retailer(BlockingQueue<Integer> inventory) {
		this.inventory = inventory;
	}

	

	@Override
	public void run() {
		while (true) {
			sellProduct(++counter);
		}
	}

	private void sellProduct(int counter)  {
		synchronized (inventory) {
			if (this.inventory.isEmpty()) {
					try {
						inventory.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
			}
				
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			this.inventory.remove(counter);
			System.out.println("Retailer is selling the item " +counter);
			inventory.notifyAll();
			
		}
	}


}
