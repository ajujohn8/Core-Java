package com.greatlearning.client;


import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import com.greatlearning.model.Distributor;
import com.greatlearning.model.Retailer;

public class InventoryManagementClient {
public static void main(String[] args) throws Exception {
		
	BlockingQueue<Integer> inventory = new ArrayBlockingQueue<>(10);
	int maxSize = 10;
	Retailer retailer = new Retailer(inventory);
	Distributor distributor = new Distributor(inventory, maxSize);
	
	Thread t1 = new Thread(retailer);
	Thread t2 = new Thread(distributor);
	
	t1.start();
	t2.start();
	t1.join();
	t2.join();
		
	}


}
