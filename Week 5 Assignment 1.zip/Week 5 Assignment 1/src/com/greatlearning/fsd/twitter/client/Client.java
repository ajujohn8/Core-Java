package com.greatlearning.fsd.twitter.client;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.greatlearning.fsd.twitter.model.Tweet;
import com.greatlearning.fsd.twitter.model.User;
import com.greatlearning.fsd.twitter.services.UserService;
import com.greatlearning.fsd.twitter.services.InMemoryUserServiceImpl;

public class Client {
	
    public static void main(String[] args) {

	UserService userService = InMemoryUserServiceImpl.getInstance();
    Set<User> usersPopulate = populateData(userService);


    System.out.println("============================Users==============================");
    printEntitySet(usersPopulate);
    System.out.println("");

    System.out.println("============================Tweets by User==============================");
    Iterator<User> it = usersPopulate.iterator();
    while(it.hasNext()){
        User user = it.next();
        if(! user.getTweets().isEmpty()) {
            System.out.println("============================Tweets by User - " + user.getFirstName() + " starts ==============================");
            printEntitySet(userService.fetchTweetsByUser(user.getId()));
            System.out.println("============================Tweets by User " + user.getFirstName() + " ends ==============================");
        }
        else
        	System.out.println("No tweets available");
    }
    System.out.println("============================Tweets by User==============================");

    System.out.println("============================Followers by User==============================");
    Iterator<User> iterateFollowers = usersPopulate.iterator();
    while(iterateFollowers.hasNext()){
        User user = iterateFollowers.next();
        if(! userService.fetchFollowersByUserId(user.getId()).isEmpty()) {
            System.out.println("============================Followers by User - " + user.getFirstName() + " starts ==============================");
            printEntitySet(userService.fetchFollowersByUserId(user.getId()));
            System.out.println("============================Followers by User " + user.getFirstName() + " ends ==============================");
        }
    }

    System.out.println(userService.suggestUsers(102));
    System.out.println("============================Tweets by User Followers==============================");
    System.out.println(userService.fetchTweetsByFollowers(101));
    System.out.println("============================Post a Tweet==========================================");
    userService.addTweet("Hello World",104L);
    userService.addTweet("Namaste",101L);
    
    System.out.println("============================View External Tweet Feed==========================================");
    System.out.println(userService.fetchTweetsByFollowingUser("vijayC"));
    
    System.out.println("============================View My Tweet Feed==========================================");
    System.out.println(userService.fetchMyTweets(104L));
    
    System.out.println("============================Like A Tweet==========================================");
    userService.addLikeToTweet(107);
    
    System.out.println("============================Comment A Tweet==========================================");
    userService.addCommentToTweet(107, "Nice");
}

private static Set<User> populateData(UserService userService) {
    Set<User> userSet = new HashSet<>();
    User user1 = userService.createUser( "ajujohn", "Aju", "John", "ajujohn@gmail.com");
    User user2 = userService.createUser( "", "Abhilash", "Mohanta", "abhiMohan@gmail.com");
    User user3 = userService.createUser( "vijayC", "Vijay", "C", "cvijay@yahoo.com");
    User user4 = userService.createUser( "samT", "Sam", "Thomas", "samthomas@gmail.com");
    User user5 = userService.createUser( "rameshMS", "Ramesh", "MS", "MSramesh@gmail.com");

    Tweet tweet1 = new Tweet("Good Morning");
    Tweet tweet2 = new Tweet("Hello India...");
    Tweet tweet3 = new Tweet("England won world cup", "http://www.icc.com/latest/news");
    Tweet tweet4 = new Tweet("Share your learing and learn from everyone.");
    Tweet tweet5 = new Tweet("Avengers is one of the best movie series","http://www.imdb.com");


    userService.addFollower(user1.getId(), user2);
    userService.addFollower(user1.getId(), user3);

    userService.addFollower(user2.getId(), user4);
    userService.addFollower(user3.getId(), user5);
    
    userService.addFollowing(user1.getId(), user2);
    userService.addFollowing(user2.getId(), user1);
    userService.addFollowing(user1.getId(), user3);
    userService.addFollowing(user3.getId(), user1);
    

    user1.addTweet(tweet1);
    user1.addTweet(tweet2);

    user2.addTweet(tweet3);
    user2.addTweet(tweet4);

    user4.addTweet(tweet5);

    userSet.add(user1);
    userSet.add(user2);
    userSet.add(user3);
    userSet.add(user4);
    userSet.add(user5);
    return userSet;
}

private static <E> void printEntitySet(Set<E> entity ){
    Iterator<E> it = entity.iterator();
    while(it.hasNext()){
        System.out.println(it.next() +"\n");
    }
}

}

	
