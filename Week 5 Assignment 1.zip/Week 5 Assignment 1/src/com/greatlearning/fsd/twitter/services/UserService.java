package com.greatlearning.fsd.twitter.services;

import java.util.Set;

import com.greatlearning.fsd.twitter.model.Tweet;
import com.greatlearning.fsd.twitter.model.User;

public interface UserService {
	
	User createUser(String userName , String emailAddress, String firstName, String lastName);
	
	User updateUser(long userId,User user);
	
	User findById(long userId);
	
	void authenticateUser(String userHandle, String Password);
	
	Set<Tweet> fetchTweetsByUser(long userId);
	
	Set<User> suggestUsers(long userId);
	
	Set<User> fetchFollowersByUserId(long userId);
	
    User findUserByUserName(String userName);

	void addFollower(long userId, User user);

	Set<Tweet> fetchTweetsByFollowers(long userId);
	    
	void addTweet(String tweetPost, Long userId);
	    
	void addTweet(String tweetPost,String mediaURL, Long userId);
	    
	Set<Tweet> fetchTweetsByFollowingUser(String username);
	   
	Set<Tweet> fetchMyTweets(Long userId);
		
	void addLikeToTweet(long tweetId);
		
	void addCommentToTweet(long tweetId,String tweetComment);

	void addFollowing(long userId, User user);

	
	}
