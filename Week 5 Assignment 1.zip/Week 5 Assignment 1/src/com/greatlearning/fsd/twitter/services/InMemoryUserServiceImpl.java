package com.greatlearning.fsd.twitter.services;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.greatlearning.fsd.twitter.model.Tweet;
import com.greatlearning.fsd.twitter.model.User;

public class InMemoryUserServiceImpl implements UserService {

	private static final Map<Long, User> users = new HashMap<>();
	private static final Map<Long, Tweet> tweets = new HashMap<>();
    private static InMemoryUserServiceImpl userService = new InMemoryUserServiceImpl();

    private InMemoryUserServiceImpl(){

    }

    public static InMemoryUserServiceImpl getInstance(){
        return userService;
    }
        
	@Override
	public User createUser(String userHandle, String emailAddress, String firstName, String lastName) {
		User user = new User(userHandle, emailAddress, firstName, lastName);		
		users.put(user.getId(), user);
		return user;
	}
	
	@Override
	public User updateUser(long userId, User user) {
		User returnedUser = findById(userId);
        if(returnedUser != null){
    
            user.setUpdatedDt(new Date());
            users.put(userId, user);
        }
        return returnedUser;
	}
	
	@Override
	public User findById(long userId) {
		return users.get(userId);
	}
	public Tweet findTweetById(long tweetId) {
		return tweets.get(tweetId);
    	
    }

    @Override
    public void authenticateUser(String username, String password) {
        User user = findUserByUserName(username);
        if (user == null ){
            throw new IllegalArgumentException("No user available");
        }
        if (! password.equals(user.getPassword())){
            throw new IllegalArgumentException("Invalid Username/password");
        }

    }

    @Override
    public Set<Tweet> fetchTweetsByUser(long userId) {
        User user = findById(userId);
        if(user == null){
            throw new IllegalArgumentException("Invalid Entity ");
        }
        return user.getTweets();
    }

    @Override
    public Set<User> suggestUsers(long userId) {
        if(findById(userId) == null){
            throw new IllegalArgumentException("Invalid Entity");
        }
        Set<Map.Entry<Long, User>> entries = users.entrySet();
        Set<User> suggestedUsers = new HashSet<>();
        Iterator<Map.Entry<Long, User>> iterator = entries.iterator();
        while (iterator.hasNext()){
            Map.Entry<Long, User> entry = iterator.next();
            long currentUserId = entry.getKey();
            if(userId == currentUserId){
                continue;
            }
            suggestedUsers.add(entry.getValue());

        }
        return suggestedUsers;
    }

    @Override
    public Set<User> fetchFollowersByUserId(long userId) {
        User user = findById(userId);
        if (user == null ){
            throw new IllegalArgumentException("No user available");
        }
        return user.getFollowers();
    }

    @Override
    public User findUserByUserName(String userName){
        Set<Map.Entry<Long, User>> entries = users.entrySet();
        Iterator<Map.Entry<Long, User>> iterator = entries.iterator();
        User selectedUser = null;
        while (iterator.hasNext()){
            Map.Entry<Long, User> entry = iterator.next();
            User user = entry.getValue();
            if(user.getUserName().equals(userName)){
                selectedUser = user;
                break;
            }
        }
        return selectedUser;
    }

    @Override
    public void addFollower(long userId, User user) {
        User fetchedUser = findById(userId);
        if (fetchedUser == null ){
            throw new IllegalArgumentException("User does not exists");
        }
        fetchedUser.addFollower(user);
    }
    
    @Override
    public void addFollowing(long userId, User user) {
        User fetchedUser = findById(userId);
        if (fetchedUser == null ){
            throw new IllegalArgumentException("User does not exists");
        }
        fetchedUser.addFollowing(user);
    }

    @Override
    public Set<Tweet> fetchTweetsByFollowers(long userId){
        User fetchedUser = findById(userId);
        Set<Tweet> tweetsByFollowers = new HashSet<>();
        if (fetchedUser == null ){
            throw new IllegalArgumentException("User does not exists");
        }
        Set<User> followers = fetchedUser.getFollowers();
        if (!followers.isEmpty()){
            Iterator<User> followersIt = followers.iterator();
            while(followersIt.hasNext()){
                User user = followersIt.next();
                tweetsByFollowers.addAll(user.getTweets());
            }
        }
        return tweetsByFollowers;
    }

	@Override
	public void addTweet(String tweetPost,Long userId) {
		Tweet tweet=new Tweet(tweetPost);
		User fetchedUser=findById(userId);
		fetchedUser.addTweet(tweet);
		tweets.put(tweet.getId(), tweet);
		System.out.println(tweet);
		System.out.println("Tweet Id : " +tweet.getId());
	}
	
	@Override
	public void addTweet(String tweetPost,String mediaURL, Long userId) {
		Tweet tweet = new Tweet(tweetPost,mediaURL);
		User fetchedUser = findById(userId);
		fetchedUser.addTweet(tweet);
		tweets.put(tweet.getId(), tweet);
	}

	@Override
	public Set<Tweet> fetchTweetsByFollowingUser(String username) {
		User user=findUserByUserName(username);
		Set<User> following = user.getFollowing();
		if(following.isEmpty()) {
			throw new IllegalArgumentException("You are not following anyone.");
		}
		Iterator<User> itr = following.iterator();
		while(itr.hasNext()) {
			User currentUser=itr.next();
			Long currentUserId=currentUser.getId();
			return fetchTweetsByUser(currentUserId);
		}
		throw new IllegalArgumentException("No Tweets.");
	}

	@Override
	public Set<Tweet> fetchMyTweets(Long userId) {
		User fetchedUser = findById(userId);
		return fetchedUser.getTweets();
	}

	@Override
	public void addLikeToTweet(long tweetId) {
		Tweet tweet=findTweetById(tweetId);
		Tweet.status status = tweet.new status();
		status.setLikes(20);
		System.out.println(status.getLikes());
	}

	@Override
	public void addCommentToTweet(long tweetId, String tweetComment) {
		Tweet tweet=findTweetById(tweetId);
		Tweet.status status = tweet.new status();
		status.setComments(tweetComment);
		
		
		System.out.println(status.getComments());
	}

	
	
	
	
}
