package com.greatlearning.fsd.module4.exceptions;

public class InvalidAmountException {

}
