package com.week4.restaurant.model;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.week4.restaurant.model.Dish;
import com.week4.restaurant.model.VegType;

public class Order {

	public static void main(String args[]) {

	System.out.println("=================Welcome=====================");
	System.out.println("Please choose from the below options");
	System.out.println("1 => To sort the dishes in the increasing order of calories");
	System.out.println("2 => To sort the dishes in the decreasing order of calories");		
	System.out.println("3 => To sort the dishes in the increasing order of price");
	System.out.println("4 => To sort the dishes in the decreasing order of price");
	System.out.println("=================*******=====================");
		
	List<Dish> dishSet= new ArrayList<>();
	
	dishSet.add(new Dish(101 , "DAL & Chappti", VegType.VEG , 705.4 , 75));
	dishSet.add(new Dish(102 , "Panner & Butter Nan" , VegType.VEG , 1250 , 140));
	dishSet.add(new Dish(103 , "Chicken Biryani" , VegType.NON_VEG , 1550.21 , 200));
	dishSet.add(new Dish(104 , "Egg Rice" , VegType.NON_VEG , 850 , 150));

	
	Scanner input = new Scanner(System.in);
	
	System.out.print("\n Please enter your choice: ");
	int option = input.nextInt();
	
	switch (option) {
	
	
	case 1:
		dishSet.sort(( dish1,  dish2 )-> dish1.calories < dish2.calories ? -1 : dish1.calories < dish2.calories ? 1 : 0 );
		System.out.println(dishSet);
	break;
	case 2:
		dishSet.sort(( dish1, dish2 )-> dish1.calories > dish2.calories ? -1 : dish1.calories > dish2.calories ? 1 : 0);
		System.out.println(dishSet);
	break;
	
	case 3:
		dishSet.sort(( dish1, dish2 ) -> dish1.price > dish2.price ? -1 : dish2.price > dish1.price ? 1 : 0);
		System.out.println(dishSet);
		break;
		
	case 4:
		dishSet.sort (( dish1 , dish2 ) -> dish1.price > dish2.price ? -1 : dish1.price > dish2.price ? 1 : 0);
		System.out.println(dishSet);
	break;
	default:
		System.out.println("Wrong Input, Choose between 1 to 3");
		break;
	}
	
	input.close();
			
}

}



