package com.week4.restaurant.model;

public enum VegType {

		VEG, 
		NON_VEG;
	}


