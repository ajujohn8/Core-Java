package com.week4.restaurant.model;


public class Dish implements Comparable<Dish> {
	private int id;
	private String name;
	private VegType vegtype;
	double calories;
	int price;


	public Dish(int id, String name, VegType vegtype, double calories, int price) {
		super();
		this.id = id;
		this.name = name;
		this.calories = calories;
		this.price = price;
	}

	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getCalories() {
		return calories;
	}
	public void setCalories(double calories) {
		this.calories = calories;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "\n" + " id=" + id + ", name=" + name + ", calories=" + calories + ", price=" + price ;
	}



	public VegType getVegtype() {
		return vegtype;
	}



	public void setVegtype(VegType vegtype) {
		this.vegtype = vegtype;
	}



	@Override
	public int compareTo(Dish o) {
		return 0;
	}

	

	}
	


