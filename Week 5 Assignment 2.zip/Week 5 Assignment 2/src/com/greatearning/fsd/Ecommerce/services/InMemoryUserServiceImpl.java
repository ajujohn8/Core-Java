package com.greatearning.fsd.Ecommerce.services;

import java.util.HashMap;
import java.util.Map;

import com.greatearning.fsd.Ecommerce.model.Address;
import com.greatearning.fsd.Ecommerce.model.Category;
import com.greatearning.fsd.Ecommerce.model.Item;
import com.greatearning.fsd.Ecommerce.model.Seller;
import com.greatearning.fsd.Ecommerce.model.User;
import com.greatearning.fsd.Ecommerce.model.Item.ItemType;

public class InMemoryUserServiceImpl implements UserService {
	
	private static final Map<Integer, User> users = new HashMap<>();
	private static final Map<Integer, Item> items = new HashMap<>();
	private static final Map<Integer, Seller> sellers = new HashMap<>();
	private static final Map<Integer, Address> addresses = new HashMap<>();
	
	
	@Override
	public User createUser(int id, String name, Address address, long contactDetails) {
		User user = new User(id, name, address, contactDetails);
		users.put(user.getId(), user);
		return user;
	}
	@Override
	public Item createItem(int id, ItemType name, String description, double price, Category category) {
		Item item = new Item(id, name, description, price, category);
		items.put(item.getId(), item);
		return item;
	}
	@Override
	public Seller createSeller(int id, String name, Address address) {
		Seller seller = new Seller(id, name, address);
		sellers.put(seller.getId(), seller);
		return seller;
	}
	@Override
	public Address createAddress(String city, String street, int zipCode) {
		Address address = new Address(city, street, zipCode);
		addresses.put(address.getZipCode(), address);
		return address;
	}
	
	
}
