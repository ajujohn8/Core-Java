package com.greatearning.fsd.Ecommerce.services;

import com.greatearning.fsd.Ecommerce.model.Address;
import com.greatearning.fsd.Ecommerce.model.Category;
import com.greatearning.fsd.Ecommerce.model.Item;
import com.greatearning.fsd.Ecommerce.model.Seller;
import com.greatearning.fsd.Ecommerce.model.User;
import com.greatearning.fsd.Ecommerce.model.Item.ItemType;

public interface UserService {
	
	User createUser(int id, String name, Address address, long contactDetails );
	Item createItem(int id, ItemType name, String description, double price, Category category );
	Seller createSeller(int id, String name, Address address);
	Address createAddress(String city, String street, int zipCode);
	

}
