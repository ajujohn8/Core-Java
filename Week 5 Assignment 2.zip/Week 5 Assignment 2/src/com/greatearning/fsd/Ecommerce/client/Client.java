package com.greatearning.fsd.Ecommerce.client;

import java.util.Scanner;

import com.greatearning.fsd.Ecommerce.model.Address;
import com.greatearning.fsd.Ecommerce.model.Category;
import com.greatearning.fsd.Ecommerce.model.CreditCard;
import com.greatearning.fsd.Ecommerce.model.DebitCard;
import com.greatearning.fsd.Ecommerce.model.Item;
import com.greatearning.fsd.Ecommerce.model.NetBanking;
import com.greatearning.fsd.Ecommerce.model.Payment;
import com.greatearning.fsd.Ecommerce.model.Seller;
import com.greatearning.fsd.Ecommerce.model.Category.CategoryType;
import com.greatearning.fsd.Ecommerce.services.InMemoryUserServiceImpl;
import com.greatearning.fsd.Ecommerce.services.UserService;

public class Client {

		public static UserService userService= new InMemoryUserServiceImpl();
		
		public static void main(String[] args) {
		Address address1 = userService.createAddress("Bangalore", "Jr Colony", 562545);
		Address address2 = userService.createAddress("Bangalore", "LakeView Colony", 560045);
		
		Seller[] sellers = new Seller[2];
		
		Seller wsRetail = userService.createSeller(1, "WS Retail", address1);
		Seller FBCloth = userService.createSeller(2, "FB Cloth", address2);
		
		sellers[0] = wsRetail;
		sellers[1] = FBCloth;
		
		Category mobileCategory = new Category(CategoryType.Mobile);
		Category fashionCategory = new Category(CategoryType.fashion);
		
		Item googlePixel1 = userService.createItem(1, Item.ItemType.GooglePixel, "Pixel Series 1", 35000, mobileCategory);
		Item googlePixel2 = userService.createItem(2, Item.ItemType.GooglePixel, "Pixel Series 2", 55000, mobileCategory);
		Item googlePixel3 = userService.createItem(3, Item.ItemType.GooglePixel, "Pixel Series 3", 75000, mobileCategory);
		
		Item moto1 = userService.createItem(1,Item.ItemType.Motorola,"moto g series 1",8000,mobileCategory);
		Item moto2= userService.createItem(2,Item.ItemType.Motorola,"moto g series 5 plus",12500,mobileCategory);
		Item moto3 = userService.createItem(3,Item.ItemType.Motorola,"moto z",27000,mobileCategory);
		Item moto4 = userService.createItem(4,Item.ItemType.Motorola,"moto x",20000,mobileCategory);
		
		Item tshirt = userService.createItem(4,Item.ItemType.Vans,"Vans Tshirt",1500,fashionCategory);
		Item shoe = userService.createItem(4,Item.ItemType.Vans,"Vans shoe",3450,fashionCategory);
		Item sandel = userService.createItem(4,Item.ItemType.Vans,"Vans Sandel",5400,fashionCategory);
		
		Item jacket = userService.createItem(4,Item.ItemType.Raymond,"Raymond Jacket",5000,fashionCategory);
		Item dress = userService.createItem(4,Item.ItemType.Raymond,"Custom Raymond dress",7000,fashionCategory);
		
		
		wsRetail.addItems(googlePixel1);
		wsRetail.addItems(googlePixel2);
		wsRetail.addItems(googlePixel3);
		wsRetail.addItems(moto1);
		wsRetail.addItems(moto2);
		wsRetail.addItems(moto3);
		wsRetail.addItems(moto4);
		
		FBCloth.addItems(shoe);
		FBCloth.addItems(sandel);
		FBCloth.addItems(jacket);
		FBCloth.addItems(dress);
		FBCloth.addItems(tshirt);
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Please select item from menu");
		System.out.println("1 Google Pixel");
		System.out.println("2 Motorola");
		System.out.println("3 Vans");
		System.out.println("4 Raymond");
		
		int option = sc.nextInt();
		
		System.out.println("Please select seller: ");

		Item.ItemType selectedItemType = null;
		switch (option) {
		case 1:
			selectedItemType = Item.ItemType.GooglePixel;
			break;

		case 2:
			selectedItemType = Item.ItemType.Motorola;
			break;
		case 3:
			selectedItemType = Item.ItemType.Vans;
			break;
		case 4:
			selectedItemType = Item.ItemType.Raymond;
			break;

		default:
			System.out.println("Please Try Again");
			break;
		}

		for(int index = 0; index < sellers.length; index ++) {
			System.out.println(sellers[index].getId() +">>>" +sellers[index].getName() +"Items "  +sellers[index].getSelectedItemCount(selectedItemType));
		}
		int userSelectedSellerNumber = sc.nextInt();
		Seller  userSelected = sellers[userSelectedSellerNumber-1];
		System.out.println("======================");	
		System.out.println("Available items: " +userSelected.getSelectedItemCount(selectedItemType));
		
		System.out.println("Select 1 for order and 2 for cancel");
		int selectedOrderOption = sc.nextInt();
		if(selectedOrderOption == 1) {
			System.out.println("Please enter Payment Type");
			System.out.println("1 => Debit Card");
			System.out.println("2 => Credit card");
			System.out.println("3 => Net Banking");
			int selectedPaymentOption =sc.nextInt();
			Payment payment =null;
			switch(selectedPaymentOption) {
			case 1:
				payment = new CreditCard("HDFC Freedom Card");
				break;
			case 2:
				payment = new DebitCard("HDFC");
				break;
			case 3:
				payment = new NetBanking("HDFC NetBanking");
				break;
			}
		if(payment != null) {
			long billNo = userSelected.order(selectedItemType, payment);
			System.out.println("Your recipt no: " + billNo);
			System.out.println("Updated available items: " + userSelected.getSelectedItemCount(selectedItemType));
			System.out.println("Seller Balance: " + userSelected.getAccountBalance());
		}
		else {
			System.out.println("Not a valid payment method");
		}
		sc.close();
		}
		

		}
}
