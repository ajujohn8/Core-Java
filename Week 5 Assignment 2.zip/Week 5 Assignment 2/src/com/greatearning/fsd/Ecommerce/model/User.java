package com.greatearning.fsd.Ecommerce.model;

public class User {
	
	private int id;
	private String name;
	private Address address;
	private long contactDetails;
	public User(int id, String name, Address address, long contactDetails) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.contactDetails = contactDetails;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public long getContactDetails() {
		return contactDetails;
	}
	public void setContactDetails(long contactDetails) {
		this.contactDetails = contactDetails;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", contactDetails=" + contactDetails + "]";
	}
	
	

}
