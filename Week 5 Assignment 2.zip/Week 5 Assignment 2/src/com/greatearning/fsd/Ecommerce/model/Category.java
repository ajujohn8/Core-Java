package com.greatearning.fsd.Ecommerce.model;

public class Category {
	
	public enum CategoryType{
		Mobile,
		fashion;
	}
	
	private CategoryType CategoryName;

	public Category(CategoryType categoryName) {
		super();
		CategoryName = categoryName;
	}

	public CategoryType getCategoryName() {
		return CategoryName;
	}

	public void setCategoryName(CategoryType categoryName) {
		CategoryName = categoryName;
	}
	
	

}
