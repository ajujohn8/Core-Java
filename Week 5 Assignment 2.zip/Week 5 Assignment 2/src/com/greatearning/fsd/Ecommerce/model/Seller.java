package com.greatearning.fsd.Ecommerce.model;
public class Seller {
	
	private int id;
	private String name;
	private Address address;
	private Item[] items = new Item[100];
	private int itemCount;
	private long orderId = 100;
	private double accountBalance;
	
	
	public Seller(int id, String name, Address address) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Address getAddress() {
		return address;
	}


	public void setAddress(Address address) {
		this.address = address;
	}
	
	public double getAccountBalance() {
		return accountBalance;
	}
	
	public void deposit(double amount) {
		this.accountBalance +=amount;
	}

	
	public void addItems(Item item) {
		if(itemCount <100) {
			this.items[itemCount] = item;
			itemCount++;
		}
		else {
			System.out.println("No of items exceeded");
		}
	}
	
	public long order(Item.ItemType itemType, Payment payment) {
		Item item = null;
		for (int i = 0; i < items.length; i++) {
			if(items[i]!=null && items[i].getName() == itemType) {
				item = items[i];
				payment.pay(item.getPrice(),this);
				items[i] = null;
				break;
			}
		}
		return item!=null ? ++orderId : 0;
	}
	
	public int getSelectedItemCount(Item.ItemType itemType) {
		int count = 0;
		//Item item = null;
		for (int i = 0; i < items.length; i++) {
			if(items[i]!=null && items[i].getName() == itemType) {
				count++;
			}
		}
		return count;
	}

	@Override
	public String toString() {
		return "Seller [id=" + id + ", name = " + name + ", address = " + address.getStreet() + address.getZipCode() + "]";
	}
	
	
	
	
}
