package com.greatearning.fsd.Ecommerce.model;

public interface Payment {
	
	public void pay(double price, Seller seller);
}
