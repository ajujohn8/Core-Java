package com.greatearning.fsd.Ecommerce.model;

public class NetBanking implements Payment{
	
		private String name;
		
		
		public NetBanking(String name) {
			super();
			this.name = name;
		}
	
		
	
		public String getName() {
			return name;
		}
	
	
	
		@Override
		public void pay(double price, Seller seller) {
			System.out.println("Payment Successfull using debit card");
			seller.deposit(price);
		}
		
}


