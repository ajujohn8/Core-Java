package com.greatearning.fsd.Ecommerce.model;

public class Address {
	
	private String city;
	private String Street;
	private int zipCode;
	public Address(String city, String street, int zipCode) {
		super();
		this.city = city;
		this.Street = street;
		this.zipCode = zipCode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getStreet() {
		return Street;
	}
	public void setStreet(String street) {
		Street = street;
	}
	public int getZipCode() {
		return zipCode;
	}
	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}
	
	

}
