package com.greatearning.fsd.Ecommerce.model;

public class CreditCard implements Payment{

	private String name;
	
	
	public CreditCard(String name) {
		super();
		this.name = name;
	}

	

	public String getName() {
		return name;
	}



	@Override
	public void pay(double price, Seller seller) {
		System.out.println("Payment Successfull using credit card");
		seller.deposit(price);
	}
	
}