package com.greatearning.fsd.Ecommerce.model;

public class Item {
	
	public enum ItemType{
		GooglePixel,
		Motorola,
		Vans,
		Raymond;
	
	}
	
	private int id;
	private ItemType name;
	private String description;
	private double price;
	private Category category;
	
	
	
	public Item(int id, ItemType name, String description, double price, Category category) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.price = price;
		this.category = category;
	}
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public ItemType getName() {
		return name;
	}
	public void setName(ItemType name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}






	
	

}
