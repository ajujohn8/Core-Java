use twitter_app;
 show tables;
 insert into user(user_handle, first_name, last_name, email_id, user_password, created_date,updated_date, profile_pic , cover_image)
	values('ajujohn8', 'Aju', 'Thomas','ajujohn@gmail.com','1234g512','2019-06-05',null,null,null),
    ('rahul9', 'Rahul', 'Mishra','rahul8@gmail.com','564n5215','2019-07-05',null,null,null),
    ('niteshojha2', 'Nitesh', 'Ojha','niteshojha@gmail.com','asd41515','2019-01-20',null,null,null),
    ('samthomas3', 'Sam', 'Thomas','samthomas@gmail.com','2154sdd','2019-04-08',null,null,null);
    
  insert into follow_following(user_id, follower_id)
  values(1,2),
  (1,2),
  (1,3),
  (1,4),
  (3,2),
  (4,2),
  (2,4),
  (3,4),
  (2,1);
  
insert into tweet( tweet_msg ,  likes, shares , created_date , user_id)
values('Opposition delegation led by Rahul Gandhi boards flight to Srinagar',54,6,'2019-08-27',1),
	('Chandrayaan 2 enters moon orbit',22,8,'2019-08-25',3),
	('Neymar expecting to join new club',6,0,'2019-07-30',2),
	('Happy working!!!',66,2,'2019-05-22',4); 
    
 insert into comments (comments, tweet_id, user_id)
 values("Nice", 2, 4),
 ("Good",2,3);
 
 select * from user;
 select * from follow_following;
 select * from tweet;
 select * from comments;
 -- drop database twitter_app;