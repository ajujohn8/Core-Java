 create database if not exists twitter_app;
 use twitter_app;
 
create table if not exists user  (
   user_id int unsigned primary key auto_increment,
   user_handle varchar(40) unique,
   first_name varchar(40),
   last_name varchar(40),
   email_id varchar(40),
   user_password varchar(40),
   created_date date,
   updated_date date,
   profile_pic binary,
   cover_image binary    
);
create table if not exists follow_following(
 id int unsigned primary key auto_increment,
 user_id int unsigned,
 constraint foreign key (user_id) references user(user_id),
 follower_id int unsigned,
 constraint foreign key (follower_id) references user(user_id)
);
create table if not exists tweet  (
   tweet_id int unsigned primary key auto_increment,
   tweet_msg varchar(250) ,
   likes int unsigned,
   shares int unsigned,
   created_date date,
    user_id int unsigned,
   constraint foreign key (user_id) references user(user_id)
   );
   
   create table if not exists comments (
  comments_id int unsigned primary key auto_increment,
  comments varchar(40),
  tweet_id int unsigned,
  constraint foreign key(tweet_id) references tweet(tweet_id),
   user_id int unsigned,
   constraint foreign key (user_id) references user(user_id)
);  
