package com.greatlearning.client;


import java.util.Scanner;
import java.util.concurrent.CountDownLatch;
import com.greatlearning.model.Bidder;
import com.greatlearning.model.Item;

public class Auction {

	@SuppressWarnings("static-access")
	public static void main(String[] args) {
				  
	Item carItem = new Item( 1, "Swift-Dezire", 500000, "good condition car");
	Item tvItem = new Item( 2, "Sony-Bravia", 10000, "in excellent condition");
	Item bikeItem = new Item( 3, "Bajaj- Pulsar", 30000, "run for 20000 Kms");
	Item macItem = new Item(4, "Macbook-Pro", 50000, "one year old laptop. Sparingly used");
	
	Thread car = new Thread(carItem);
	Thread tv = new Thread(tvItem);
	Thread bike = new Thread(bikeItem);
	Thread laptop = new Thread(macItem);
	
	car.setName("Swift Dezire");
	tv.setName("Sony Bravia");
	bike.setName("Pulsar");
	laptop.setName("MacPro");

	CountDownLatch bidderLatch = new CountDownLatch(4);

	Thread vinay =new Thread(new Bidder(1, "Vinay",bidderLatch));
	Thread krishna =new Thread(new Bidder(2, "Krishna",bidderLatch));
	Thread mohan = new Thread(new Bidder(3, "Mohan",bidderLatch));
	Thread rohan = new Thread(new Bidder(4, "Rohan",bidderLatch));

	
	double sellingPrice= 0, price1 = 0,price2 = 0, price3 = 0,price4 = 0;
	Scanner sc = new Scanner(System.in);
		
	car.start();			
	try {
		 car.sleep(2000);
		
		 vinay.start();
		 vinay.sleep(2000);
		 System.out.println(" ===============Please enter your bid price ==========");
		 price1 = sc.nextDouble();
	 	 
		 krishna.start();
	 	 System.out.println(" ===============Please enter your bid price ==========");
		 price2 = sc.nextDouble();
	 	 
		 mohan.start();
	 	 System.out.println(" ===============Please enter your bid price ==========");
		 price3 = sc.nextDouble();
 	  	
		 rohan.start();
 	 	 System.out.println(" ===============Please enter your bid price ==========");
		 price4 = sc.nextDouble();
		 sellingPrice = Math.max(Math.max(price1, price2),Math.max(price3,price4));
		 System.out.println(" ============" + car.getName() +"Sold Price: "+ sellingPrice + "=================== ");
		
		 car.join();
		 vinay.join();
		 krishna.join();
		 mohan.join();
		 rohan.join();
	 } catch (InterruptedException e) {
		e.printStackTrace();
	}
		 vinay =new Thread(new Bidder(1, "Vinay",bidderLatch));
		 krishna =new Thread(new Bidder(2, "Krishna",bidderLatch));
		 mohan = new Thread(new Bidder(3, "Mohan",bidderLatch));
		 rohan = new Thread(new Bidder(4, "Rohan",bidderLatch));
		 tv.start();
	try {
		tv.sleep(2000);
	   	
		vinay.start();
		vinay.sleep(2000);
	    System.out.println(" ===============Please enter your bid price ==========");
	    price1 = sc.nextDouble();
		
	     krishna.start();
		System.out.println(" ===============Please enter your bid price ==========");
		price2 = sc.nextDouble();
		
		mohan.start();
		System.out.println(" ===============Please enter your bid price ==========");
		price3 = sc.nextDouble();
		
		rohan.start();
		System.out.println(" ===============Please enter your bid price ==========");
		price4 = sc.nextDouble();
		
		sellingPrice = Math.max(Math.max(price1, price2),Math.max(price3,price4));
		System.out.println(" ============" + tv.getName() +" Sold Price: " + sellingPrice + "=================== ");
		tv.join();
		vinay.join();
		 krishna.join();
		 mohan.join();
		 rohan.join();
	 } catch (InterruptedException e) {
		e.printStackTrace();
	}
		 vinay =new Thread(new Bidder(1, "Vinay", bidderLatch));
		 krishna =new Thread(new Bidder(2, "Krishna", bidderLatch));
		 mohan = new Thread(new Bidder(3, "Mohan", bidderLatch));
		 rohan = new Thread(new Bidder(4, "Rohan", bidderLatch));
		 bike.start();
	try {
		bike.sleep(2000);
		
	   	vinay.start();
		vinay.sleep(2000);
	    System.out.println(" ===============Please enter your bid price ==========");
	     price1 = sc.nextDouble();
		
	     krishna.start();
		System.out.println(" ===============Please enter your bid price ==========");
		 price2 = sc.nextDouble();
		
		 mohan.start();
		System.out.println(" ===============Please enter your bid price ==========");
		 price3 = sc.nextDouble();
		
		 rohan.start();
		System.out.println(" ===============Please enter your bid price ==========");
		price4 = sc.nextDouble();
		
		sellingPrice = Math.max(Math.max(price1, price2),Math.max(price3,price4));
		System.out.println(" ============" + bike.getName() +" Sold Price: "+ sellingPrice + "=================== ");
		bike.join();
		 vinay.join();
		 krishna.join();
		 mohan.join();
		 rohan.join();
	 } catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		 vinay =new Thread(new Bidder(1, "Vinay",bidderLatch));
		 krishna =new Thread(new Bidder(2, "Krishna",bidderLatch));
		 mohan = new Thread(new Bidder(3, "Mohan",bidderLatch));
		 rohan = new Thread(new Bidder(4, "Rohan",bidderLatch));
		 laptop.start();
			try {
				laptop.sleep(2000);
		
				vinay.start();
				vinay.sleep(2000);
			    System.out.println(" ===============Please enter your bid price ==========");
			     price1 = sc.nextDouble();
				
			     krishna.start();
				System.out.println(" ===============Please enter your bid price ==========");
				 price2 = sc.nextDouble();
				
				 mohan.start();
				System.out.println(" ===============Please enter your bid price ==========");
				 price3 = sc.nextDouble();
				
				 rohan.start();
				System.out.println(" ===============Please enter your bid price ==========");
				price4 = sc.nextDouble();
				
				sellingPrice = Math.max(Math.max(price1, price2),Math.max(price3,price4));
				System.out.println(" ============" + laptop.getName() +" Sold Price: "+ sellingPrice + "=================== ");
				laptop.join();
				 vinay.join();
				 krishna.join();
				 mohan.join();
				 rohan.join();
			 } catch (InterruptedException e) {
				e.printStackTrace();
	
			 }
			sc.close();
	}
	

}
