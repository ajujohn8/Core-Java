package com.greatlearning.model;

import java.util.concurrent.CountDownLatch;

public class Bidder implements Runnable {
	private long id;
    private String name;
    private CountDownLatch countDownLatch;
    
	public Bidder(long id, String name, CountDownLatch countDownLatch) {
		super();
		this.id = id;
		this.name = name;
		this.countDownLatch = countDownLatch;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public CountDownLatch getCountDownLatch() {
		return countDownLatch;
	}

	public void setCountDownLatch(CountDownLatch countDownLatch) {
		this.countDownLatch = countDownLatch;
	}

	@Override
	public String toString() {
		return "Bidder id= " + id + ", Name=" + name;
	}

	@Override
	public void run() {
		try {
	         System.out.println(id +": Name "  + name);
	        Thread.sleep(2000);
	      } catch (InterruptedException e) {
	         System.out.println(e.getMessage());
	      }
	      countDownLatch.countDown();	
	}
    
}
